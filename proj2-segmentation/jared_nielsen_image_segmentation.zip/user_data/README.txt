Place any additional images / user input (e.g. files with selected point locations for each image) here.

When trying to run your notebook we will copy the notebook itself and this folder of images/user data, before running it.  So please have your notebook refer to needed images/data, e.g. as 'user_data/my_image.png' and perhaps 'user_data/my_image-selected_pts.json' for example.  It's up to you what you call the files, etc. because your notebook will load them, but make sure they're in and referred to in the user_data folder.
